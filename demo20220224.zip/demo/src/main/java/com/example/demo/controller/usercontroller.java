package com.example.demo.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.dao.DAO;
import com.example.demo.medel.User;
import net.bytebuddy.implementation.bind.annotation.Empty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/users",method = RequestMethod.POST)
public class usercontroller {
    @Autowired
    private  DAO userDao;
    /*获取数据库内信息*/
    @GetMapping(value = "/")
    public List<User> getUsers(){
        return userDao.findAll();
    }
    /*登录*/
    @PostMapping(value = "/login")
    public  String  login(String userName , String passWord){
       String result = "Data";
        User user = new User();
        List<User> c = userDao.findByUser(userName);
        user = c.get(0);
        if(user.getPassWord().equals(passWord)){
             result = "success";
        }
        return result;
    }
    /*添加数据库内信息*/
    @PostMapping(value = "/add")
    public Map<String,Object> addUsers(@RequestParam  String userName , @RequestParam  String passWord){
        Map<String,Object> result = new HashMap<>();
        userName = userName.replaceAll("\\s*|\t|\r|\n","");
        passWord = passWord.replaceAll("\\s*|\t|\n|\n","");
        User user = new User();
        List<User> c = userDao.findByUser(userName);
        try {
            user = c.get(0);
        }catch (Exception e){

        }
        if (userName.equals(user.getUserName())){
              result.put("success","已有相同账号");
              return result;
        }else{
            if (userName.isEmpty()){
                result.put("success", "账号不能为空");
                return result;
            }else
            if (passWord.isEmpty()){
                result.put("success", "密码不能为空");
                return result;
            }else{
                User u = new User();
                u.setUserName(userName);
                u.setPassWord(passWord);
                userDao.save(u);
                result.put("success","true");
                return result;
            }

        }
    }
}
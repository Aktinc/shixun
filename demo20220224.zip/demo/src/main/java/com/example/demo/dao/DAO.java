package com.example.demo.dao;


import com.example.demo.medel.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DAO extends JpaRepository<User,Long> {
    List<User> findAll();
    @Query(name="findByID",nativeQuery = true,value = "select * from User where id=:id")
    List<User> findByID(@Param("id") int id); //引用id,对数据库进行查询

    @Query(name="findByUser",nativeQuery = true,value = "select * from User where user_name=:String ")
    List<User> findByUser(@Param("String") String string); //引用id,对数据库进行查询
}

package com.example.demo.dao;

import com.example.demo.medel.Sensor;
import com.example.demo.medel.SensorId;
import com.example.demo.medel.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface SensorDAO extends JpaRepository<Sensor, SensorId> {
    List<Sensor> findAll();
    @Query(name="findBytype",nativeQuery = true,value = "select * from sensor where type =:type ")
    List<Sensor> findBytype(@Param("type") int type); //引用type,对数据库进行查询
}

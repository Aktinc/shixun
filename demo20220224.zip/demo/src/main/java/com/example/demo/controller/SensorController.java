package com.example.demo.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.Service.SensorService;
import com.example.demo.dao.SensorDAO;
import com.example.demo.medel.Sensor;
import com.example.demo.medel.SensorId;
import com.example.demo.medel.User;
import org.apache.juli.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



@RestController
@RequestMapping(value = "/SEN",method = RequestMethod.POST)
public class SensorController {

    @Autowired
    private SensorService sensorService;
    @Autowired
    private SensorDAO sensorDAO;


    @PostMapping("/sensor")
    public Map<String , Object> addSensor(@RequestParam int type,@RequestParam float value){
        Map<String,Object> result = new HashMap<>();
        result.put("success",true);
        Sensor sensor = new Sensor();
        sensor.setValue(value);
        SensorId sensorId = new SensorId();
        sensorId.setType(type);
        sensorId.setTimestamp(Timestamp.from(Instant.now()));
        sensor.setSensorId(sensorId);

        if(sensorService.addSensor(sensor) == null){
            result.put("success",false);
        } else {
            result.put("data",sensor);
        }
        return result;
    }
    /*
     *历史数据查询
     * value:光照度数据
     * ty :type
     *
     */
    @PostMapping("/Inquire")
    public  String  Inquire(@RequestParam int type){
        //声明json数组
        JSONArray gResTable = new JSONArray();
        JSONObject outData = new JSONObject();
        outData.put("gRestTable",gResTable);
        List<Sensor> sensors = sensorDAO.findBytype(type);
        Sensor sensor = new Sensor();
        SensorId sensorid = new SensorId();

        for (int num =1; num<sensorDAO.findBytype(type).size();num++ ){
            sensor = sensors.get(num);
            float value = sensor.getValue();
            sensorid  = sensor.getSensorId();
            int ty    = sensorid.getType();
            Timestamp time = sensorid.getTimestamp();
            JSONObject node = new JSONObject();
            node.put("value",""+value);
            node.put("type",""+type);
            node.put("Time",time.toString());
            gResTable.add(node);
        }
        return  outData.toJSONString();
    }
}

package com.example.demo.medel;

import javax.persistence.*;

@Entity
@Table(name = "sensor")
public class Sensor {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EmbeddedId private SensorId sensorId;
    private float value;
    public SensorId getSensorId() {
        return sensorId;
    }
    public void setSensorId(SensorId sensorId) {
        this.sensorId = sensorId;
    }
    public float getValue() {
        return value;
    }
    public void setValue(float value)
    { this.value = value; }

}

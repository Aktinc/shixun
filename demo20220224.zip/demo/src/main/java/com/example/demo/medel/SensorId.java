package com.example.demo.medel;

import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;
import java.sql.Timestamp;

@Embeddable
public class SensorId implements Serializable {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public static final int SENSOR_LIGHT = 1;
    private Timestamp timestamp;
    private int type;
    public  SensorId(){

    }
    public Timestamp getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }
}
